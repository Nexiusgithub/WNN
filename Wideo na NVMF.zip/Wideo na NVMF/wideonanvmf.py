import os
import tempfile
import moviepy.editor as mp
import numpy as np
import cv2
from pydub import AudioSegment
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QFileDialog, QDialog, QTextEdit, QHBoxLayout, QMenuBar
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QPixmap, QPalette, QColor, QIcon

class PostProcessingWindow(QDialog):
    def __init__(self, video_path, parent=None):
        super().__init__(parent)
        self.video_path = video_path
        self.initUI()

    def initUI(self):
        # Set the window flags to remove the title bar and any window controls
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        layout = QVBoxLayout()

        label = QLabel(f'Processing complete. The video has been saved as:\n{self.video_path}')
        label.setAlignment(Qt.AlignCenter)
        font = QFont('Arial', 12, QFont.Bold)
        label.setFont(font)
        layout.addWidget(label)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)  # Adjust spacing between buttons

        btn_play = QPushButton('Play Video')
        btn_play.setFixedSize(180, 60)
        btn_play.setFont(QFont('Arial', 12, QFont.Bold))
        btn_play.setIcon(QIcon('Resources/OW.png'))  # Updated icon path
        btn_play.setIconSize(QSize(30, 30))  # Adjust icon size
        btn_play.clicked.connect(self.play_video)
        button_layout.addWidget(btn_play)

        btn_find = QPushButton('Find Video')
        btn_find.setFixedSize(180, 60)
        btn_find.setFont(QFont('Arial', 12, QFont.Bold))
        btn_find.setIcon(QIcon('Resources/ZW.png'))  # Updated icon path
        btn_find.setIconSize(QSize(30, 30))  # Adjust icon size
        btn_find.clicked.connect(self.open_folder)
        button_layout.addWidget(btn_find, alignment=Qt.AlignRight)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def play_video(self):
        try:
            os.startfile(self.video_path)
        except Exception as e:
            print(f'Error opening video: {e}')

    def open_folder(self):
        try:
            folder = os.path.dirname(self.video_path)
            os.startfile(folder)
        except Exception as e:
            print(f'Error opening folder: {e}')

class VideoConverterApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.video_path = None

    def initUI(self):
        self.setWindowTitle('Video Converter')
        self.setGeometry(100, 100, 600, 400)

        palette = QPalette()
        palette.setColor(QPalette.Background, QColor('#F0F0F0'))
        self.setPalette(palette)

        layout = QVBoxLayout()

        # Add PNG logo from the Resources folder
        self.logo_label = QLabel(self)
        pixmap = QPixmap('Resources/wideonanvmf.png')  # Path to your logo PNG file in Resources folder
        pixmap = pixmap.scaled(300, 75, Qt.KeepAspectRatio)  # Resize logo
        self.logo_label.setPixmap(pixmap)
        self.logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.logo_label)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(5)  # Adjust spacing between buttons

        btn_open = QPushButton('Wybierz wideo')
        btn_open.setFixedSize(200, 50)
        btn_open.setFont(QFont('Arial', 12, QFont.Bold))
        btn_open.setIcon(QIcon('Resources/WW.png'))  # Keep icon path
        btn_open.setIconSize(QSize(30, 30))  # Adjust icon size
        btn_open.clicked.connect(self.openAndConvert)
        button_layout.addWidget(btn_open)

        self.info_button = QPushButton('Pytania i Odpowiedzi')
        self.info_button.setFixedSize(200, 50)
        self.info_button.setFont(QFont('Arial', 12, QFont.Bold))
        self.info_button.setIcon(QIcon('Resources/P&O.png'))  # Keep icon path
        self.info_button.setIconSize(QSize(30, 30))  # Adjust icon size
        self.info_button.clicked.connect(self.show_info)
        button_layout.addWidget(self.info_button, alignment=Qt.AlignRight)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def show_info(self):
        info_text = (
            "Co to jest Wideo na NVMF?:\n"
            "Wideo na NVMF to taki konwerter którym zmieni każde formaty "
            "(oprócz nvmf bo nvmf na nvmf nie da się)\n"
            "Co to właściwie kurna NVMF?:\n"
            "NVMF (czyli Nexius Video Media Format) to taki mój stworzony "
            "format którym wygląda jak każde filmy z początków 2000-tych, "
            "zainspirowałem się facedev jak zrobił format zdjęcia o nazwie 'bruh'\n"
            "Jak to działa?:\n"
            "Jak to działa?, jeśli wybierasz randomowy film z formatem dla "
            "przykład MP4, zaczyna się procesowanie, procesuje jako MP4 i "
            "stworzony jako NVMF"
        )
        info_dialog = QDialog(self)
        info_dialog.setWindowTitle("Pytania i Odpowiedzi")
        info_dialog.setGeometry(100, 100, 500, 400)
        layout = QVBoxLayout()
        text_edit = QTextEdit()
        text_edit.setText(info_text)
        text_edit.setFont(QFont('Arial', 14))  # Increased text size
        text_edit.setReadOnly(True)
        layout.addWidget(text_edit)
        info_dialog.setLayout(layout)
        info_dialog.exec_()

    def add_colorful_noise(self, frame):
        frame_float = frame.astype(np.float32)
        noise_intensity = 20  # Adjusted noise intensity
        noise = np.random.normal(loc=0, scale=noise_intensity, size=frame.shape).astype(np.float32)
        noisy_frame = np.clip(frame_float + noise, 0, 255).astype(np.uint8)
        return noisy_frame

    def simulate_jpeg_quality(self, frame):
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 20]
        result, encimg = cv2.imencode('.jpg', frame, encode_param)
        return cv2.imdecode(encimg, 1)

    def adjust_audio_bitrate(self, audio_segment, bitrate="32k"):
        temp_audio_path = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3').name
        audio_segment.export(temp_audio_path, format='mp3', bitrate=bitrate)
        return AudioSegment.from_mp3(temp_audio_path)

    def reduce_audio_quality(self, audio_segment):
        # Reduce the sample rate and bitrate for lower quality audio
        low_quality_audio = audio_segment.set_frame_rate(8000)  # Lower the sample rate
        low_quality_audio = self.adjust_audio_bitrate(low_quality_audio, bitrate="24k")  # Lower the bitrate
        return low_quality_audio

    def convertToNVMF(self):
        if not self.video_path:
            return

        sanitized_video_name = self.sanitize_filename(os.path.basename(self.video_path))
        temp_video_path = tempfile.NamedTemporaryFile(delete=False, suffix='.mp4').name
        output_path = os.path.join(os.path.dirname(self.video_path), sanitized_video_name.rsplit('.', 1)[0] + '.nvmf')
        audio_path = None
        processed_audio_path = None

        try:
            print("Ładowanie wideo...")
            clip = mp.VideoFileClip(self.video_path)
            if clip.audio is None:
                raise ValueError("Brak ścieżki audio w wideo.")

            print("Zmiana rozmiaru wideo...")
            resized_clip = clip.resize(height=200)

            def process_frame(frame):
                noisy_frame = self.add_colorful_noise(frame)
                jpeg_frame = self.simulate_jpeg_quality(noisy_frame)
                return jpeg_frame

            print("Przetwarzanie klatek...")
            processed_clip = resized_clip.fl_image(process_frame)

            print("Ustawianie FPS...")
            final_clip = processed_clip.set_fps(20)  # Set the FPS to 20

            print("Przetwarzanie audio...")
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                audio_path = temp_file.name
                clip.audio.write_audiofile(audio_path, codec='pcm_s16le')

            audio_segment = AudioSegment.from_wav(audio_path)
            processed_audio_segment = self.reduce_audio_quality(audio_segment)

            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                processed_audio_path = temp_file.name
                processed_audio_segment.export(processed_audio_path, format='wav')

            final_clip = final_clip.set_audio(mp.AudioFileClip(processed_audio_path))
            final_clip.write_videofile(temp_video_path, codec='libx264', audio_codec='aac', preset='ultrafast')

            try:
                os.remove(audio_path)
                os.remove(processed_audio_path)
            except Exception as e:
                print(f"Failed to delete temporary files: {e}")

            print(f"Zapisano wideo jako: {output_path}")
            os.rename(temp_video_path, output_path)
            self.show_post_processing_window(output_path)

        except Exception as e:
            print(f"Błąd podczas konwersji: {e}")

    def sanitize_filename(self, filename):
        return ''.join(c for c in filename if c.isalnum() or c in (' ', '.', '_')).rstrip()

    def cleanup_temp_files(self, files):
        for file in files:
            try:
                os.remove(file)
                print(f"Usunięto plik tymczasowy: {file}")
            except Exception as e:
                print(f"Nie udało się usunąć pliku: {file}. Błąd: {e}")

    def show_post_processing_window(self, video_path):
        self.post_processing_window = PostProcessingWindow(video_path, self)
        self.post_processing_window.exec_()

    def openAndConvert(self):
        file_dialog = QFileDialog(self)
        file_dialog.setFileMode(QFileDialog.ExistingFiles)
        file_dialog.setNameFilter("Pliki wideo (*.mp4 *.avi *.mov *.mkv)")
        file_dialog.setViewMode(QFileDialog.List)

        if file_dialog.exec_() == QDialog.Accepted:
            file_paths = file_dialog.selectedFiles()
            if file_paths:
                self.video_path = file_paths[0]
                self.convertToNVMF()

if __name__ == '__main__':
    import sys
    app = QApplication(sys.argv)
    converter = VideoConverterApp()
    converter.show()
    sys.exit(app.exec_())
